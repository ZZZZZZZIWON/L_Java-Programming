package chap02;

import java.util.Scanner;

public class ex05 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("���� 3���� �Է��Ͻÿ�>>");

		int a = scan.nextInt();
		int b = scan.nextInt();
		int c = scan.nextInt();
		
		if(a>b) {
			
		}
		
		

		scan.close();

	}
}
